package ao.uan.fc.dam.exercicioiii;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private EditText editText;
    private ListView listView;
    private ArrayAdapter<String> adapter;
    private ArrayList<String> taskList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d("MainActivity","Starting My ACtivity");

        editText = (EditText)findViewById(R.id.edit_text);
        listView = (ListView) findViewById(R.id.list_view);

        taskList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, taskList);
        listView.setAdapter(adapter);

        editText.setOnEditorActionListener((v, keyCode, event) -> {

            if (keyCode == EditorInfo.IME_ACTION_DONE) {
                addTask();
                editText.getText().clear();
                Log.d("MainActivity","Inside Event");
                return true;
            }
            return false;
        });
    }
	
	 private void addTask() {
		String task = editText.getText().toString();
         	
         	//just add if user has written something
		 if (!task.isEmpty()) {
		 	    Log.d("MainActivity","adding  the tasktask");
			    taskList.add(0, task);
			    adapter.notifyDataSetChanged();
			    editText.getText().clear();
			}

		 }

}
