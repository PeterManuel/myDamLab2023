package ao.uan.fc.dam.mybroadcasttest;

import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ReadNoteActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_read_note);

        TextView titleTextView = findViewById(R.id.titleTextView);
        TextView contentTextView = findViewById(R.id.contentTextView);
        Button backButton = findViewById(R.id.backButton);

        String title = getIntent().getStringExtra("title");
        titleTextView.setText(title);

        backButton.setOnClickListener(v -> finish());
    }
}
