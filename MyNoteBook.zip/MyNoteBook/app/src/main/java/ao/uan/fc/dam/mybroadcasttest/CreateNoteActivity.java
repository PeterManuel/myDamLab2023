package ao.uan.fc.dam.mybroadcasttest;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class CreateNoteActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_note);

        final EditText titleEditText = findViewById(R.id.titleEditText);
        final EditText contentEditText = findViewById(R.id.contentEditText);

        Button cancelButton = findViewById(R.id.cancelButton);
        cancelButton.setOnClickListener(v -> {
            setResult(RESULT_CANCELED);
            finish();
        });

        Button okButton = findViewById(R.id.okButton);
        okButton.setOnClickListener(v -> {
            String noteTitle = titleEditText.getText().toString();
            String noteContent = contentEditText.getText().toString();

            Intent intent = new Intent();
            intent.putExtra("noteTitle", noteTitle);
            intent.putExtra("noteContent", noteContent);
            setResult(RESULT_OK, intent);
            finish();
        });
    }
}
