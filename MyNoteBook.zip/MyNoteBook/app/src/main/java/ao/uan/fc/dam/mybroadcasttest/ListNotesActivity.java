package ao.uan.fc.dam.mybroadcasttest;

import android.content.Intent;
import android.os.Bundle;

import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class ListNotesActivity extends AppCompatActivity {

    private List<String> noteTitles;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_note);

        noteTitles = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, noteTitles);

        ListView listView = findViewById(R.id.listView);
        listView.setAdapter(adapter);

        Button newNoteButton = findViewById(R.id.newNoteButton);
        newNoteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ListNotesActivity.this, CreateNoteActivity.class);
                startActivityForResult(intent, 1);
            }
        });

        listView.setOnItemClickListener((parent, view, position, id) -> {
            String title = noteTitles.get(position);
            Intent intent = new Intent(ListNotesActivity.this, ReadNoteActivity.class);
            intent.putExtra("title", title);
            startActivity(intent);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == RESULT_OK) {
            String noteTitle = data.getStringExtra("noteTitle");
            noteTitles.add(noteTitle);
            adapter.notifyDataSetChanged();
        }
    }
}
