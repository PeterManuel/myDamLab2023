package ao.uan.fc.dam.mycallerregister;
import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.CallLog;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private static final int PERMISSION_REQUEST_CODE = 1;

    private ListView callListView;
    private CallLogAdapter callLogAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        callListView = findViewById(R.id.callListView);
        callLogAdapter = new CallLogAdapter(this, new ArrayList<>());
        callListView.setAdapter(callLogAdapter);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_CALL_LOG}, PERMISSION_REQUEST_CODE);
        } else {
            loadCallLog();
        }
    }

    private void loadCallLog() {
        Cursor cursor = getContentResolver().query(CallLog.Calls.CONTENT_URI, null, null, null, CallLog.Calls.DATE + " DESC");
        if (cursor == null) {
            Toast.makeText(this, "Failed to load call log.", Toast.LENGTH_SHORT).show();
            return;
        }

        ArrayList<CallLogEntry> callLogs = new ArrayList<>();

        int numberIndex = cursor.getColumnIndex(CallLog.Calls.NUMBER);
        int nameIndex = cursor.getColumnIndex(CallLog.Calls.CACHED_NAME);
        int typeIndex = cursor.getColumnIndex(CallLog.Calls.TYPE);
        int dateIndex = cursor.getColumnIndex(CallLog.Calls.DATE);

        while (cursor.moveToNext()) {
            String number = cursor.getString(numberIndex);
            String name = cursor.getString(nameIndex);
            int type = cursor.getInt(typeIndex);
            long date = cursor.getLong(dateIndex);

            callLogs.add(new CallLogEntry(name, number, type, date));
        }

        cursor.close();

        callLogAdapter.setCallLogs(callLogs);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                loadCallLog();
            } else {
                Toast.makeText(this, "Permission is required to access call logs.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
