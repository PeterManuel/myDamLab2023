package ao.uan.fc.dam.mycallerregister;

public class CallLogEntry {
    private String callerName;
    private String callerNumber;
    private int callType;
    private long callDate;

    public CallLogEntry(String callerName, String callerNumber, int callType, long callDate) {
        this.callerName = callerName;
        this.callerNumber = callerNumber;
        this.callType = callType;
        this.callDate = callDate;
    }

    public String getCallerName() {
        return callerName;
    }

    public String getCallerNumber() {
        return callerNumber;
    }

    public int getCallType() {
        return callType;
    }

    public long getCallDate() {
        return callDate;
    }
}
