package ao.uan.fc.dam.mycallerregister;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Environment;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;

import androidx.core.app.ActivityCompat;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Locale;

public class CallLogger {
    private static final String FILE_NAME = "call_log.txt";
    private static final String LOG_FORMAT = "caller_name: %s, caller_number: %s\n";
    private Context context;

    public CallLogger(Context context) {
        this.context = context;
    }

    public void startCallLogging() {
        TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        PhoneStateListener phoneStateListener = new PhoneStateListener() {
            @Override
            public void onCallStateChanged(int state, String phoneNumber) {
                super.onCallStateChanged(state, phoneNumber);
                if (state == TelephonyManager.CALL_STATE_RINGING) {
                    String callerName = getCallerName(phoneNumber);
                    String logEntry = String.format(Locale.getDefault(), LOG_FORMAT, callerName, phoneNumber);
                    writeLogEntry(logEntry);
                }
            }
        };

        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
            telephonyManager.listen(phoneStateListener, PhoneStateListener.LISTEN_CALL_STATE);
        }
    }

    private String getCallerName(String phoneNumber) {
        // You can implement a lookup mechanism here to retrieve the caller's name based on the phone number
        // For simplicity, let's return the phone number itself as the caller's name
        return phoneNumber;
    }

    private void writeLogEntry(String logEntry) {
        try {
            File logFile = new File(Environment.getExternalStorageDirectory(), FILE_NAME);
            FileWriter fileWriter = new FileWriter(logFile, true);
            fileWriter.append(logEntry);
            fileWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
