package ao.uan.fc.dam.mycallerregister;

import android.content.Context;
import android.provider.CallLog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class CallLogAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<CallLogEntry> callLogs;

    public CallLogAdapter(Context context, ArrayList<CallLogEntry> callLogs) {
        this.context = context;
        this.callLogs = callLogs;
    }

    public void setCallLogs(ArrayList<CallLogEntry> callLogs) {
        this.callLogs = callLogs;
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return callLogs.size();
    }

    @Override
    public Object getItem(int position) {
        return callLogs.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.call_log_item, parent, false);

            holder = new ViewHolder();
            holder.callerNameTextView = convertView.findViewById(R.id.callerNameTextView);
            holder.callerNumberTextView = convertView.findViewById(R.id.callerNumberTextView);
            holder.callTypeTextView = convertView.findViewById(R.id.callTypeTextView);
            holder.callDateTextView = convertView.findViewById(R.id.callDateTextView);

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        CallLogEntry callLog = callLogs.get(position);

        holder.callerNameTextView.setText(callLog.getCallerName());
        holder.callerNumberTextView.setText(callLog.getCallerNumber());

        int callType = callLog.getCallType();
        String callTypeText;
        switch (callType) {
            case CallLog.Calls.INCOMING_TYPE:
                callTypeText = "Incoming";
                break;
            case CallLog.Calls.OUTGOING_TYPE:
                callTypeText = "Outgoing";
                break;
            case CallLog.Calls.MISSED_TYPE:
                callTypeText = "Missed";
                break;
            default:
                callTypeText = "Unknown";
                break;
        }
        holder.callTypeTextView.setText(callTypeText);

        Date date = new Date(callLog.getCallDate());
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
        holder.callDateTextView.setText(dateFormat.format(date));

        return convertView;
    }

    private static class ViewHolder {
        TextView callerNameTextView;
        TextView callerNumberTextView;
        TextView callTypeTextView;
        TextView callDateTextView;
    }
}
